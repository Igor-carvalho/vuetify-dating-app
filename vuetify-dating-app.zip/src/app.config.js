export default {
    BASE_URL: 'https://cloudpad9.com',
    API_BASE: 'https://api.cloudpad9.com'
}
