import authActions from './actions/auth'
import userActions from './actions/user'

export default {
    ...authActions,
    ...userActions
}
