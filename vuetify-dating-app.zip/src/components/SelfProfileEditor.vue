<template>
  <div>
    Component::SelfProfileEditor
  </div>
</template>

<script>
export default {
  name: 'SelfProfileEditor',
  props: {

  }
}
</script>

<style lang="scss">
</style>
