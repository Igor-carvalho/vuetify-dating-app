<template>
  <div>
    Component::SelfProfile
  </div>
</template>

<script>
export default {
  name: 'SelfProfile',
  props: {

  }
}
</script>

<style lang="scss">
</style>
