<template>
  <div>
    Component::DreamPartnerProfile
  </div>
</template>

<script>
export default {
  name: 'DreamPartnerProfile',
  props: {

  }
}
</script>

<style lang="scss">
</style>
