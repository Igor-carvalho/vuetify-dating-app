<template>
  <div>
    Component::ProfileSearch
  </div>
</template>

<script>
export default {
  name: 'ProfileSearch',
  props: {

  }
}
</script>

<style lang="scss">
</style>
