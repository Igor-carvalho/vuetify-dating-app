<template>
  <div>
    Component::RequestList
  </div>
</template>

<script>
export default {
  name: 'RequestList',
  props: {

  }
}
</script>

<style lang="scss">
</style>
