<template>
  <div>
    Component::DreamPartnerProfileEditor
  </div>
</template>

<script>
export default {
  name: 'DreamPartnerProfileEditor',
  props: {

  }
}
</script>

<style lang="scss">
</style>
