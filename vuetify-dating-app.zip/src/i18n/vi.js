export default {
    'Username': 'Tên đăng nhập',
    'Password': 'Mật khẩu'
}
