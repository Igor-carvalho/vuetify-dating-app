<template>
  <div>
    TODO::Profile search
  </div>
</template>

<script>
export default {
  name: 'ProfileSearch',
  components: {
  }
}
</script>
