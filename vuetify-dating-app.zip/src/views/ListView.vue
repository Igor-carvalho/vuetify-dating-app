<template>
  <div>
    TODO::ListView
  </div>
</template>

<script>
export default {
  name: 'ListView',
  components: {
  }
}
</script>
