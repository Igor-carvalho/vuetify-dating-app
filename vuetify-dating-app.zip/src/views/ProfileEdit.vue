<template>
  <div>
    TODO::Profile edit
  </div>
</template>

<script>
export default {
  name: 'ProfileEdit',
  components: {
  }
}
</script>
