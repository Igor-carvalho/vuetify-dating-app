<template>
  <div>
    TODO::Dream partner edit
  </div>
</template>

<script>
export default {
  name: 'DreamPartnerEdit',
  components: {
  }
}
</script>
