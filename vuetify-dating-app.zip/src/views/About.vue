<template>
  <div class="about">
    <v-app>
      <v-toolbar app>
        <v-toolbar-title>My Application</v-toolbar-title>
      </v-toolbar>
      <v-navigation-drawer app></v-navigation-drawer>
      <v-content>
        <v-container fluid>
          Hello World
        </v-container>
      </v-content>
      <v-footer></v-footer>
    </v-app>
  </div>
</template>
